﻿namespace DemoLibrary.Utilities
{
    public interface ILogger
    {
        void Log(string message);
    }
}